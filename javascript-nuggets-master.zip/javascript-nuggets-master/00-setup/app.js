//  Javascript Nuggets
